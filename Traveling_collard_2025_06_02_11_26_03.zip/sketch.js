let trees = [];

let score = 0;

let wateringCan;

function setup() {

  createCanvas(600, 400);

  wateringCan = createButton('Regar Árvore');

  wateringCan.position(10, height + 10);

  wateringCan.mousePressed(waterTree);

}

function draw() {

  background(135, 206, 235); // Céu azul claro

  

  // Solo

  fill(85, 107, 47);

  rect(0, height - 50, width, 50);

  // Mostrar e atualizar árvores

  for (let tree of trees) {

    tree.show();

    tree.grow();

  }

  

  // Mostrar pontuação

  fill(0);

  textSize(18);

  text('Pontuação: ' + score, 10, 30);

}

function mousePressed() {

  // Planta uma nova árvore na posição clicada (se estiver no chão)

  if (mouseY > height - 50) {

    trees.push(new Tree(mouseX, height - 50));

  }

}

function waterTree() {

  // Regar a árvore mais próxima do mouse (dentro de 50px)

  if (trees.length === 0) return;

  

  let closest = null;

  let closestDist = 50;

  

  for (let tree of trees) {

    let d = dist(mouseX, mouseY, tree.x, tree.y);

    if (d < closestDist) {

      closestDist = d;

      closest = tree;

    }

  }

  

  if (closest) {

    closest.water();

    score += 5;

  }

}

class Tree {

  constructor(x, groundY) {

    this.x = x;

    this.y = groundY;

    this.height = 20;

    this.waterLevel = 0;

  }

  

  show() {

    // Tronco

    fill(139, 69, 19);

    rect(this.x - 5, this.y - this.height, 10, this.height);

    

    // Folhagem

    fill(34, 139, 34, 200);

    ellipse(this.x, this.y - this.height, this.height, this.height);

  }

  

  grow() {

    if (this.waterLevel > 0 && this.height < 100) {

      this.height += 0.1;

      this.waterLevel -= 0.05;

    }

  }

  

  water() {

    this.waterLevel += 2;

  }

}





  